Imports System.Collections.Generic
Imports Utilities.FTP

Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        'EXAMPLE OF HOW TO USE FtpWebRequest

        'Values to use
        Const localFile As String = "C:\file.bin"
        Const remoteFile As String = "/ftpfile.bin"
        Const host As String = "ftp://ftp.myserver.com"
        Const username As String = "myusername"
        Const password As String = "mypassword"

        'Create a request
        Dim URI As String = host & remoteFile
        Dim ftp As System.Net.FtpWebRequest = CType(System.Net.FtpWebRequest.Create(URI), System.Net.FtpWebRequest)
        'Set the credentials
        ftp.Credentials = New System.Net.NetworkCredential(username, password)
        'Turn off KeepAlive (will close connection on completion)
        ftp.KeepAlive = False
        'we want a binary 
        ftp.UseBinary = True
        'Define the action required (in this case, download a file)
        ftp.Method = System.Net.WebRequestMethods.Ftp.DownloadFile

        'If we were using a method that uploads data e.g. UploadFile
        'we would open the ftp.GetRequestStream here an send the data

        'Get the response to the Ftp request and the associated stream
        Using response As System.Net.FtpWebResponse = CType(ftp.GetResponse, System.Net.FtpWebResponse)
            Using responseStream As IO.Stream = response.GetResponseStream
                'loop to read & write to file
                Using fs As New IO.FileStream(localFile, IO.FileMode.Create)
                    Dim buffer(2047) As Byte
                    Dim read As Integer = 0
                    Do
                        read = responseStream.Read(buffer, 0, buffer.Length)
                        fs.Write(buffer, 0, read)
                    Loop Until read = 0 'see Note(1)
                    responseStream.Close()
                    fs.Flush()
                    fs.Close()
                End Using
                responseStream.Close()
            End Using
            response.Close()
        End Using

    End Sub

    'An example of FtpClient usage
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click

        'Create a link to an FtpServer
        Dim ftp As New FTPclient("ftp.myhost.com", "myusername", "mypassword")

        'download a file (permitting overwrite)
        ftp.Download("/pub/ftpfile.bin", "C:\test\ftp\ftpfile.bin", True)

        'upload a file
        ftp.Upload("c:\test\ftp\upload.exe", "/pub/upload.exe")

        'does a file exist?
        If ftp.FtpFileExists("/pub/upload.exe") Then
            'rename a file
            ftp.FtpRename("/pub/upload.exe", "/pub/newname.exe")
            'delete a file
            ftp.FtpDelete("/pub/newname.exe")
        End If

        'get a simple listing of the root directory /
        Dim result As List(Of String) = ftp.ListDirectory("/")
        'display in console
        Console.WriteLine("Directory listing of /")
        For Each line As String In result
            Console.WriteLine(line)
        Next

        'Get the detailed directory listing of /pub/
        Dim dirList As FTPdirectory = ftp.ListDirectoryDetail("/pub/")

        'filter out only the files in the list
        Dim filesOnly As FTPdirectory = dirList.GetFiles()

        'download these files
        For Each file As FTPfileInfo In filesOnly
            ftp.Download(file, "C:\test\ftp\" & file.Filename, True)
        Next


    End Sub
End Class
