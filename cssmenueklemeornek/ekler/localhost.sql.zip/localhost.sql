-- phpMyAdmin SQL Dump
-- version 4.4.0
-- http://www.phpmyadmin.net
--
-- Anamakine: localhost
-- Üretim Zamanı: 21 Ağu 2015, 01:07:15
-- Sunucu sürümü: 5.5.11
-- PHP Sürümü: 5.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Veritabanı: `deneme_db`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `altkategori`
--

CREATE TABLE IF NOT EXISTS `altkategori` (
  `id` int(11) NOT NULL,
  `kategoriid` varchar(10) DEFAULT NULL,
  `ad` varchar(250) DEFAULT NULL,
  `link` varchar(250) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin5;

--
-- Tablo döküm verisi `altkategori`
--

INSERT INTO `altkategori` (`id`, `kategoriid`, `ad`, `link`) VALUES
(1, '2', 'hayvan resimleri', 'hresim.aspx'),
(2, '2', 'doğa resimkleri', 'dresim.aspx'),
(3, '2', 'deniz resimleri', 'deresim.aspx'),
(4, '3', 'yerli müzikler', 'ymuzik.aspx'),
(5, '3', 'yabanci müzik', 'ymuzik.aspx'),
(6, '3', 'türküler', 'turku.aspx'),
(7, '4', 'ziyaretçi defteri', 'zdefter.aspx'),
(8, '4', 'hakımızda', 'hakk.aspx'),
(9, '7', 'gdfgfdg', 'fgdfgd'),
(10, '7', 'ryyrty', 'tryrtytr');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kategori`
--

CREATE TABLE IF NOT EXISTS `kategori` (
  `id` int(11) NOT NULL,
  `ad` varchar(250) DEFAULT NULL,
  `link` varchar(250) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin5;

--
-- Tablo döküm verisi `kategori`
--

INSERT INTO `kategori` (`id`, `ad`, `link`) VALUES
(1, 'Anasayfa', 'Default.aspx'),
(2, 'Resimler', 'resimler.aspx'),
(3, 'müzikler', 'muzikler.aspx'),
(4, 'iletişim', 'iletisim.aspx'),
(7, 'sanana', 'sfsfsdf');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL,
  `kulad` varchar(100) DEFAULT NULL,
  `sifre` varchar(100) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin5;

--
-- Tablo döküm verisi `users`
--

INSERT INTO `users` (`id`, `kulad`, `sifre`, `email`) VALUES
(15, 'ffdfd', 'dfdf', 'dfdf'),
(16, 'ffdfd', 'dfdf', 'dfdf'),
(17, 'ffdfd', 'dfdf', 'dfdf'),
(18, '1111', '111', '111');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `altkategori`
--
ALTER TABLE `altkategori`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `altkategori`
--
ALTER TABLE `altkategori`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- Tablo için AUTO_INCREMENT değeri `kategori`
--
ALTER TABLE `kategori`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- Tablo için AUTO_INCREMENT değeri `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
